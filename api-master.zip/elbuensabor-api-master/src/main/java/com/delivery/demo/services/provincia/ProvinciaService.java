package com.delivery.demo.services.provincia;

import com.delivery.demo.entities.direccion.Provincia;
import com.delivery.demo.services.base.BaseService;

public interface ProvinciaService extends BaseService<Provincia, Long> {
}
