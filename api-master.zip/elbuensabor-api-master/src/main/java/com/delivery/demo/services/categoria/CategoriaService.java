package com.delivery.demo.services.categoria;

import com.delivery.demo.entities.articulos.Categoria;
import com.delivery.demo.services.base.BaseService;

public interface CategoriaService extends BaseService<Categoria, Long> {
}
