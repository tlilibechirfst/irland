package com.delivery.demo.services.rol;

import com.delivery.demo.entities.usuarios.Rol;
import com.delivery.demo.services.base.BaseService;

public interface RolService extends BaseService<Rol, Long> {
}
