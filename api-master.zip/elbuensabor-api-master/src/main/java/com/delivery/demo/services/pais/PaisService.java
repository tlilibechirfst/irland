package com.delivery.demo.services.pais;

import com.delivery.demo.entities.direccion.Pais;
import com.delivery.demo.services.base.BaseService;

public interface PaisService extends BaseService<Pais, Long> {
}
