package com.delivery.demo.services.datosEmpresa;

import com.delivery.demo.entities.DatosEmpresa;
import com.delivery.demo.services.base.BaseService;

public interface DatosEmpresaService extends BaseService<DatosEmpresa, Long> {
}
