package com.delivery.demo.services.direccionLegal;

import com.delivery.demo.entities.direccion.DireccionLegal;
import com.delivery.demo.services.base.BaseService;

public interface DireccionLegalService extends BaseService<DireccionLegal, Long> {
}
