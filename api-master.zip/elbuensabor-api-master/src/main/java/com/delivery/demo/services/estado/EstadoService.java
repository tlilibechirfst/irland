package com.delivery.demo.services.estado;

import com.delivery.demo.entities.comprobantes.Estado;
import com.delivery.demo.services.base.BaseService;

public interface EstadoService extends BaseService<Estado, Long> {
}
