package com.delivery.demo.services.localidad;

import com.delivery.demo.entities.direccion.Localidad;
import com.delivery.demo.services.base.BaseService;

public interface LocalidadService extends BaseService<Localidad, Long> {
}
