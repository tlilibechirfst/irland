package com.delivery.demo.services.direccionDelivery;

import com.delivery.demo.entities.direccion.DireccionDelivery;
import com.delivery.demo.services.base.BaseService;

public interface DireccionDeliveryService extends BaseService<DireccionDelivery, Long> {
}
