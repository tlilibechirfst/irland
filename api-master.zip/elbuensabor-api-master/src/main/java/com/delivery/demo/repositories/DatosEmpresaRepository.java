package com.delivery.demo.repositories;

import com.delivery.demo.entities.DatosEmpresa;

public interface DatosEmpresaRepository extends BaseRepository<DatosEmpresa, Long> {
}
